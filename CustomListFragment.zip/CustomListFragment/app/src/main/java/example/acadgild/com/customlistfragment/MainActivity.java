package example.acadgild.com.customlistfragment;

import android.app.ListActivity;
import android.os.Bundle;

/**
 * Created by admin on 9/24/2015.
 */
public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        getFragmentManager().findFragmentById(R.id.fragmentlist);
    }
}
